#pragma once

#include "Window.h"
#include "VulkanInstance.h"
#include "VulkanSurface.h"
#include "VulkanDevice.h"      // <-- ����� ��������
#include "VulkanSwapchain.h"
#include "VulkanSync.h"
#include "VulkanCommand.h"
#include "VulkanRenderer.h"
#include "VulkanPipeline.h"
#include "VulkanRenderPass.h"


class Application {
public:
    bool init();
    void run();
    void cleanup();

private:
    Window window;
    VulkanInstance instance;
    VulkanSurface surface;
    VulkanDevice device;
    VulkanSwapchain swapchain;
    VulkanSync sync;
    VulkanCommand command;
    VulkanRenderer renderer;
    VulkanPipeline pipeline;

};
