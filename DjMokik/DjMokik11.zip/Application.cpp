﻿#include "Application.h"
#include <iostream>

bool Application::init() {
    // Инициализация окна
    if (!window.init(800, 600, "DjMokik")) {
        std::cerr << "Failed to create window!" << std::endl;
        return false;
    }

    // Инициализация Vulkan Instance
    if (!instance.init("DjMokik")) {
        std::cerr << "Failed to init Vulkan Instance!" << std::endl;
        return false;
    }

    // Инициализация Vulkan Surface
    if (!surface.init(instance.get(), window.get())) {
        std::cerr << "Failed to create Vulkan Surface!" << std::endl;
        return false;
    }

    // 🔥 ВАЖНО – сначала инициализируем устройство
    if (!device.init(instance.get(), surface.get())) {
        std::cerr << "Failed to init Vulkan Device!" << std::endl;
        return false;
    }

    // Инициализация Swapchain
    if (!swapchain.init(
        device.getPhysicalDevice(),
        device.getDevice(),
        surface.get()
    )) {
        std::cerr << "Failed to init Vulkan Swapchain!" << std::endl;
        return false;
    }

    

    std::cout << "Init sync...\n";
    if (!sync.init(device.getDevice())) {
        std::cerr << "Failed to init Vulkan Sync!" << std::endl;
        return false;
    }

    std::cout << "Init command...\n";
    if (!command.init(
        device.getDevice(),
        swapchain,
        device.getGraphicsQueueFamily()
    )) {
        std::cerr << "Failed to init Vulkan Command!" << std::endl;
        return false;
    }

    std::cout << "Init pipeline...\n";
    if (!pipeline.init(device.getDevice(), swapchain.getRenderPass())) {
        std::cerr << "Failed to create pipeline\n";
        return false;
    }


	std::cout << "Init renderer...\n";
    if (!renderer.init(device, swapchain, command, sync, pipeline)) {
        std::cerr << "Failed to init VulkanRenderer!" << std::endl;
        return false;
    }

    std::cout << "All initialized!\n";
    return true;
}

void Application::run() {
    while (!window.shouldClose()) {
        window.pollEvents();

        // Получаем командные буферы
        auto& buffers = command.getBuffers();
        renderer.drawFrame();

        // Пока просто будем симулировать использование
        // (реальный submit добавим дальше)
    }
    vkDeviceWaitIdle(device.getDevice());
}


void Application::cleanup() {
    sync.cleanup(device.getDevice());
    command.cleanup(device.getDevice());
    pipeline.cleanup(device.getDevice());
    swapchain.cleanup(device.getDevice());
    surface.cleanup(instance.get());
    device.cleanup();
    instance.cleanup();
    window.cleanup();
}
