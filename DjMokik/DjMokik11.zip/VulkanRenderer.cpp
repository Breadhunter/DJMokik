﻿#include "VulkanRenderer.h"
#include <iostream>

bool VulkanRenderer::init(
    VulkanDevice& deviceRef,
    VulkanSwapchain& swapchainRef,
    VulkanCommand& commandRef,
    VulkanSync& syncRef,
    VulkanPipeline& pipelineRef
) {
    device = &deviceRef;
    swapchain = &swapchainRef;
    command = &commandRef;
    sync = &syncRef;
    pipeline = &pipelineRef;

    std::vector<Vertex> vertices = {
        {{ 0.0f, -0.5f, 0.0f }, {1.0f, 0.0f, 0.0f}},
        {{ 0.5f,  0.5f, 0.0f }, {0.0f, 1.0f, 0.0f}},
        {{-0.5f,  0.5f, 0.0f }, {0.0f, 0.0f, 1.0f}}
    };

    if (!mesh.create(*device, vertices)) {
        std::cerr << "Failed to create mesh!" << std::endl;
        return false;
    }

    if (!command->recordCommands(
        *swapchain,
        pipeline->get(),
        mesh
    )) {
        std::cerr << "Failed to record command buffers!" << std::endl;
        return false;
    }

    return true;
}

void VulkanRenderer::drawFrame() {
    uint32_t imageIndex;

    vkAcquireNextImageKHR(
        device->getDevice(),
        swapchain->get(),
        UINT64_MAX,
        sync->getImageAvailable(),
        VK_NULL_HANDLE,
        &imageIndex
    );

    VkSubmitInfo submitInfo{};
    submitInfo.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;

    VkSemaphore waitSemaphores[] = { sync->getImageAvailable() };
    VkSemaphore signalSemaphores[] = { sync->getRenderFinished() };

    VkPipelineStageFlags waitStages[] = {
        VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT
    };

    VkCommandBuffer cmd = command->getCommandBuffer(imageIndex);

    submitInfo.waitSemaphoreCount = 1;
    submitInfo.pWaitSemaphores = waitSemaphores;
    submitInfo.pWaitDstStageMask = waitStages;

    submitInfo.commandBufferCount = 1;
    submitInfo.pCommandBuffers = &cmd;

    submitInfo.signalSemaphoreCount = 1;
    submitInfo.pSignalSemaphores = signalSemaphores;

    vkQueueSubmit(
        device->getGraphicsQueue(),
        1,
        &submitInfo,
        VK_NULL_HANDLE
    );

    VkPresentInfoKHR presentInfo{};
    presentInfo.sType = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR;

    presentInfo.waitSemaphoreCount = 1;
    presentInfo.pWaitSemaphores = signalSemaphores;

    VkSwapchainKHR swapchains[] = { swapchain->get() };

    presentInfo.swapchainCount = 1;
    presentInfo.pSwapchains = swapchains;
    presentInfo.pImageIndices = &imageIndex;

    vkQueuePresentKHR(
        device->getPresentQueue(),
        &presentInfo
    );

    vkQueueWaitIdle(device->getPresentQueue());
}

void VulkanRenderer::cleanup() {
    mesh.cleanup(device->getDevice());
}
