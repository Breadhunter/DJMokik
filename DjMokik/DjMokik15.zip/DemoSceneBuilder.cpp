#include "DemoSceneBuilder.h"

void DemoSceneBuilder::build(Scene& scene, VulkanMeshManager& meshManager) {

    std::vector<Vertex> vertices = {
        {{ 0.0f, -0.5f, 0.0f }, {1.0f, 0.0f, 0.0f}},
        {{ 0.5f,  0.5f, 0.0f }, {0.0f, 1.0f, 0.0f}},
        {{-0.5f,  0.5f, 0.0f }, {0.0f, 0.0f, 1.0f}}
    };

    VulkanMesh& mesh = meshManager.createMesh(vertices);

    scene.addMesh(mesh);
}
