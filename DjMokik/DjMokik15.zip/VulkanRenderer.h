#pragma once

#include "VulkanMeshManager.h"
#include "VulkanRenderContext.h"
#include "VulkanFrameManager.h"
#include "VulkanCommandRecorder.h"

class Scene;

class VulkanRenderer {
public:
    bool init(VulkanRenderContext& ctx);

    void drawScene(Scene& scene);

    void cleanup();

    VulkanMeshManager& getMeshManager();
    void recordScene(const Scene& scene);


private:
    VulkanRenderContext* context = nullptr;

    VulkanMeshManager meshManager;
    VulkanFrameManager frameManager;
    VulkanCommandRecorder recorder;
};
