﻿#include "VulkanRenderer.h"
#include "Scene.h"
#include <iostream>

bool VulkanRenderer::init(VulkanRenderContext& ctx) {

    context = &ctx;

    if (!meshManager.init(ctx.getDevice())) {
        std::cerr << "Failed to init mesh manager\n";
        return false;
    }

    recorder.init(ctx.getCommand());

    frameManager.init(ctx.getDevice(), 2);

    return true;
}

void VulkanRenderer::recordScene(const Scene& scene) {

    if (scene.getMeshes().empty()) {
        std::cerr << "Scene is empty - nothing to record!\n";
        return;
    }

    // Пока берём только первый меш (позже будет цикл)
    VulkanMesh* mesh = scene.getMeshes()[0];

    recorder.record(
        context->getSwapchain(),
        context->getPipeline(),
        *mesh
    );
}


void VulkanRenderer::drawScene(Scene& scene) {

    uint32_t imageIndex = frameManager.beginFrame(
        context->getDevice(),
        context->getSwapchain()
    );

    VkCommandBuffer cmd =
        context->getCommand().getCommandBuffer(imageIndex);

    // В будущем тут будет recordCommands(scene)
    // Пока просто сабмитим уже записанные команды

    frameManager.submitFrame(
        context->getDevice(),
        context->getDevice().getGraphicsQueue(),
        cmd,
        context->getSwapchain(),
        imageIndex
    );
}

void VulkanRenderer::cleanup() {

    meshManager.cleanup(context->getDevice().getDevice());

    frameManager.cleanup(context->getDevice().getDevice());
}

VulkanMeshManager& VulkanRenderer::getMeshManager() {
    return meshManager;
}
