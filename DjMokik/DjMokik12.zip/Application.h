#pragma once

#include "Window.h"
#include "VulkanInstance.h"
#include "VulkanSurface.h"
#include "VulkanDevice.h"
#include "VulkanSwapchain.h"
#include "VulkanCommand.h"
#include "VulkanPipeline.h"
#include "VulkanMesh.h"
#include "VulkanCommandRecorder.h"
#include "VulkanRenderer.h"

class Application {
public:
    bool init();
    void run();
    void cleanup();

private:
    Window window;

    VulkanInstance instance;
    VulkanSurface surface;
    VulkanDevice device;
    VulkanSwapchain swapchain;
    VulkanCommand command;
    VulkanPipeline pipeline;

    VulkanMesh mesh;

    VulkanCommandRecorder recorder;

    VulkanRenderer renderer;
};
