﻿#include "VulkanRenderer.h"

bool VulkanRenderer::init(
    VulkanDevice& deviceRef,
    VulkanSwapchain& swapchainRef,
    VulkanCommand& commandRef
) {
    device = &deviceRef;
    swapchain = &swapchainRef;
    command = &commandRef;

    frameManager.init(deviceRef, 2);

    return true;
}

void VulkanRenderer::setMesh(VulkanMesh& m) {
    mesh = &m;
}

void VulkanRenderer::drawFrame() {
    uint32_t imageIndex = frameManager.beginFrame(*device, *swapchain);

    VkCommandBuffer cmd = command->getCommandBuffer(imageIndex);

    frameManager.submitFrame(
        *device,
        device->getGraphicsQueue(),
        cmd,
        *swapchain,
        imageIndex
    );
}

void VulkanRenderer::cleanup() {
    frameManager.cleanup(device->getDevice());
}
