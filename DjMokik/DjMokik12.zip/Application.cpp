﻿#include "Application.h"
#include <iostream>

bool Application::init() {

    if (!window.init(800, 600, "DjMokik")) {
        std::cerr << "Failed to create window!" << std::endl;
        return false;
    }

    if (!instance.init("DjMokik")) {
        std::cerr << "Failed to init Vulkan Instance!" << std::endl;
        return false;
    }

    if (!surface.init(instance.get(), window.get())) {
        std::cerr << "Failed to create Vulkan Surface!" << std::endl;
        return false;
    }

    if (!device.init(instance.get(), surface.get())) {
        std::cerr << "Failed to init Vulkan Device!" << std::endl;
        return false;
    }

    if (!swapchain.init(
        device.getPhysicalDevice(),
        device.getDevice(),
        surface.get()
    )) {
        std::cerr << "Failed to init Vulkan Swapchain!" << std::endl;
        return false;
    }

    if (!command.init(
        device.getDevice(),
        swapchain,
        device.getGraphicsQueueFamily()
    )) {
        std::cerr << "Failed to init Vulkan Command!" << std::endl;
        return false;
    }

    if (!pipeline.init(device.getDevice(), swapchain.getRenderPass())) {
        std::cerr << "Failed to create pipeline\n";
        return false;
    }

    // Создаём тестовый меш
    std::vector<Vertex> vertices = {
        {{ 0.0f, -0.5f, 0.0f }, {1.0f, 0.0f, 0.0f}},
        {{ 0.5f,  0.5f, 0.0f }, {0.0f, 1.0f, 0.0f}},
        {{-0.5f,  0.5f, 0.0f }, {0.0f, 0.0f, 1.0f}}
    };

    if (!mesh.create(device, vertices)) {
        std::cerr << "Failed to create mesh\n";
        return false;
    }

    // Запись команд рендеринга
    recorder.init(command);

    if (!recorder.record(swapchain, pipeline, mesh)) {
        std::cerr << "Failed to record commands\n";
        return false;
    }

    // Инициализация Renderer-а
    if (!renderer.init(device, swapchain, command)) {
        std::cerr << "Failed to init renderer\n";
        return false;
    }

    renderer.setMesh(mesh);

    std::cout << "All initialized successfully!\n";
    return true;
}


void Application::run() {
    while (!window.shouldClose()) {
        window.pollEvents();

        renderer.drawFrame();
    }

    vkDeviceWaitIdle(device.getDevice());
}


void Application::cleanup() {

    renderer.cleanup();

    mesh.cleanup(device.getDevice());

    pipeline.cleanup(device.getDevice());
    command.cleanup(device.getDevice());
    swapchain.cleanup(device.getDevice());

    surface.cleanup(instance.get());
    device.cleanup();
    instance.cleanup();
    window.cleanup();
}
