#pragma once

#include "VulkanMesh.h"
#include "VulkanFrameManager.h"
#include "VulkanDevice.h"
#include "VulkanSwapchain.h"
#include "VulkanCommand.h"

class VulkanRenderer {
public:
    bool init(
        VulkanDevice& device,
        VulkanSwapchain& swapchain,
        VulkanCommand& command
    );

    void setMesh(VulkanMesh& mesh);
    void drawFrame();
    void cleanup();

private:
    VulkanDevice* device = nullptr;
    VulkanSwapchain* swapchain = nullptr;
    VulkanCommand* command = nullptr;

    VulkanMesh* mesh = nullptr;

    VulkanFrameManager frameManager;
};
