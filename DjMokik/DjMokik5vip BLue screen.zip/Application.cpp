﻿#include "Application.h"
#include <iostream>

bool Application::init() {
    // Инициализация окна
    if (!window.init(800, 600, "DjMokik")) {
        std::cerr << "Failed to create window!" << std::endl;
        return false;
    }

    // Инициализация Vulkan Instance
    if (!instance.init("DjMokik")) {
        std::cerr << "Failed to init Vulkan Instance!" << std::endl;
        return false;
    }

    // Инициализация Vulkan Surface
    if (!surface.init(instance.get(), window.get())) {
        std::cerr << "Failed to create Vulkan Surface!" << std::endl;
        return false;
    }

    // 🔥 ВАЖНО – сначала инициализируем устройство
    if (!device.init(instance.get(), surface.get())) {
        std::cerr << "Failed to init Vulkan Device!" << std::endl;
        return false;
    }

    // Инициализация Swapchain
    if (!swapchain.init(
        device.getPhysicalDevice(),
        device.getDevice(),
        surface.get()
    )) {
        std::cerr << "Failed to init Vulkan Swapchain!" << std::endl;
        return false;
    }

    if (!sync.init(device.getDevice())) {
        std::cerr << "Failed to init Vulkan Sync!" << std::endl;
        return false;
    }

    if (!command.init(
        device.getDevice(),
        swapchain,
        device.getGraphicsQueueFamily()
    )) {
        std::cerr << "Failed to init Vulkan Command!" << std::endl;
        return false;
    }
    if (!command.recordEmptyCommands(swapchain)) {
        std::cerr << "Failed to record command buffers!" << std::endl;
        return false;
    }
    command.recordCommands(swapchain);

    if (!renderer.init(device, swapchain, command, sync)) {
        std::cerr << "Failed to init VulkanRenderer!" << std::endl;
        return false;
    }

    return true;
}

void Application::run() {
    while (!window.shouldClose()) {
        window.pollEvents();

        // Получаем командные буферы
        auto& buffers = command.getBuffers();
        renderer.drawFrame();

        // Пока просто будем симулировать использование
        // (реальный submit добавим дальше)
    }
    vkDeviceWaitIdle(device.getDevice());
}


void Application::cleanup() {
    sync.cleanup(device.getDevice());
    command.cleanup(device.getDevice());
    swapchain.cleanup(device.getDevice());
    surface.cleanup(instance.get());
    device.cleanup();
    instance.cleanup();
    window.cleanup();
}
