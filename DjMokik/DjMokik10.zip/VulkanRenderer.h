#pragma once
#include "VulkanRenderer.h"
#include "VulkanDevice.h"
#include "VulkanSwapchain.h"
#include "VulkanCommand.h"
#include "VulkanSync.h"
#include "VulkanPipeline.h"
#include "Vertex.h"
#include <vector>
#include "VulkanBuffer.h"
#include "VulkanMesh.h"

class VulkanRenderer {
public:
    bool init(
        VulkanDevice& device,
        VulkanSwapchain& swapchain,
        VulkanCommand& command,
        VulkanSync& sync,
        VulkanPipeline& pipeline
    );

    void createVertexBuffer();
    void drawFrame();
    void cleanup();

private:
    VulkanDevice* device = nullptr;
    VulkanSwapchain* swapchain = nullptr;
    VulkanCommand* command = nullptr;
    VulkanSync* sync = nullptr;
    VulkanPipeline* pipeline = nullptr;
    VulkanMesh mesh;

    uint32_t findMemoryType(uint32_t typeFilter, VkMemoryPropertyFlags properties);
};
