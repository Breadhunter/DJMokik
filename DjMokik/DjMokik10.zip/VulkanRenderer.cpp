﻿#include "VulkanRenderer.h"
#include <vulkan/vulkan.h>
#include <iostream>

bool VulkanRenderer::init(
    VulkanDevice& device,
    VulkanSwapchain& swapchain,
    VulkanCommand& command,
    VulkanSync& sync,
    VulkanPipeline& pipeline
) {
    this->device = &device;
    this->swapchain = &swapchain;
    this->command = &command;
    this->sync = &sync;
    this->pipeline = &pipeline;

    createVertexBuffer();

    // ВАЖНО: использовать this-> !!!

    this->command->recordCommands(
        *this->swapchain,
        this->pipeline->get(),
        mesh.getBuffer()
    );

    return true;
}



void VulkanRenderer::drawFrame() {

    VkDevice vkDevice = device->getDevice();
    VkQueue graphicsQueue = device->getGraphicsQueue();
    VkQueue presentQueue = device->getPresentQueue();

    VkSemaphore imageAvailable = sync->getImageAvailableSemaphore();
    VkSemaphore renderFinished = sync->getRenderFinishedSemaphore();
    VkFence inFlightFence = sync->getInFlightFence();

    vkWaitForFences(vkDevice, 1, &inFlightFence, VK_TRUE, UINT64_MAX);
    vkResetFences(vkDevice, 1, &inFlightFence);

    uint32_t imageIndex;
    vkAcquireNextImageKHR(
        vkDevice,
        swapchain->get(),
        UINT64_MAX,
        imageAvailable,
        VK_NULL_HANDLE,
        &imageIndex
    );

    // 🔥 БЕРЕМ УЖЕ ГОТОВЫЙ command buffer
    VkCommandBuffer commandBuffer = command->getCommandBuffer(imageIndex);

    VkSubmitInfo submitInfo{};
    submitInfo.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;

    VkSemaphore waitSemaphores[] = { imageAvailable };
    VkPipelineStageFlags waitStages[] = { VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT };

    submitInfo.waitSemaphoreCount = 1;
    submitInfo.pWaitSemaphores = waitSemaphores;
    submitInfo.pWaitDstStageMask = waitStages;

    submitInfo.commandBufferCount = 1;
    submitInfo.pCommandBuffers = &commandBuffer;

    VkSemaphore signalSemaphores[] = { renderFinished };
    submitInfo.signalSemaphoreCount = 1;
    submitInfo.pSignalSemaphores = signalSemaphores;

    vkQueueSubmit(graphicsQueue, 1, &submitInfo, inFlightFence);

    VkPresentInfoKHR presentInfo{};
    presentInfo.sType = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR;

    presentInfo.waitSemaphoreCount = 1;
    presentInfo.pWaitSemaphores = signalSemaphores;

    VkSwapchainKHR swapChains[] = { swapchain->get() };
    presentInfo.swapchainCount = 1;
    presentInfo.pSwapchains = swapChains;
    presentInfo.pImageIndices = &imageIndex;

    vkQueuePresentKHR(presentQueue, &presentInfo);
}


void VulkanRenderer::cleanup() {
    mesh.cleanup(device->getDevice());
}


void VulkanRenderer::createVertexBuffer() {

    std::vector<Vertex> vertices = {
    { {0.0f, -0.5f, 0.0f}, {1.0f, 0.0f, 0.0f} },
    { {0.5f,  0.5f, 0.0f}, {0.0f, 1.0f, 0.0f} },
    { {-0.5f, 0.5f, 0.0f}, {0.0f, 0.0f, 1.0f} }
    };

    mesh.create(*device, vertices);
}





uint32_t VulkanRenderer::findMemoryType(uint32_t typeFilter, VkMemoryPropertyFlags properties) {

    VkPhysicalDeviceMemoryProperties memProperties;
    vkGetPhysicalDeviceMemoryProperties(device->getPhysicalDevice(), &memProperties);

    for (uint32_t i = 0; i < memProperties.memoryTypeCount; i++) {
        if (typeFilter & (1 << i) &&
            (memProperties.memoryTypes[i].propertyFlags & properties) == properties) {
            return i;
        }
    }

    throw std::runtime_error("Failed to find suitable memory type!");
}