#include "Engine.h"

bool Engine::init(Window& w) {
    window = &w;

    if (!renderer.init(w)) {
        return false;
    }

    return true;
}

void Engine::run() {
    while (!window->shouldClose()) {
        window->pollEvents();
        renderer.drawFrame();
    }
}

void Engine::cleanup() {
    renderer.cleanup();
}
