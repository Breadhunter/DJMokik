﻿#include "VulkanRenderer.h"
#include <vulkan/vulkan.h>
#include <iostream>

bool VulkanRenderer::init(
    VulkanDevice& device,
    VulkanSwapchain& swapchain,
    VulkanCommand& command,
    VulkanSync& sync,
    VulkanPipeline& pipeline
) {
    this->device = &device;
    this->swapchain = &swapchain;
    this->command = &command;
    this->sync = &sync;
    this->pipeline = &pipeline;

    createVertexBuffer();

    // ВАЖНО: использовать this-> !!!

    this->command->setVertexBuffer(vertexBuffer.get());
    this->command->setPipeline(
        this->pipeline->get(),
        this->pipeline->getLayout()
    );

    this->command->recordCommands(*this->swapchain);

    return true;
}



void VulkanRenderer::drawFrame() {

    VkDevice vkDevice = device->getDevice();
    VkQueue graphicsQueue = device->getGraphicsQueue();
    VkQueue presentQueue = device->getPresentQueue();

    VkSemaphore imageAvailable = sync->getImageAvailableSemaphore();
    VkSemaphore renderFinished = sync->getRenderFinishedSemaphore();
    VkFence inFlightFence = sync->getInFlightFence();

    vkWaitForFences(vkDevice, 1, &inFlightFence, VK_TRUE, UINT64_MAX);
    vkResetFences(vkDevice, 1, &inFlightFence);

    uint32_t imageIndex;
    vkAcquireNextImageKHR(
        vkDevice,
        swapchain->get(),
        UINT64_MAX,
        imageAvailable,
        VK_NULL_HANDLE,
        &imageIndex
    );

    // 🔥 БЕРЕМ УЖЕ ГОТОВЫЙ command buffer
    VkCommandBuffer commandBuffer = command->getCommandBuffer(imageIndex);

    VkSubmitInfo submitInfo{};
    submitInfo.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;

    VkSemaphore waitSemaphores[] = { imageAvailable };
    VkPipelineStageFlags waitStages[] = { VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT };

    submitInfo.waitSemaphoreCount = 1;
    submitInfo.pWaitSemaphores = waitSemaphores;
    submitInfo.pWaitDstStageMask = waitStages;

    submitInfo.commandBufferCount = 1;
    submitInfo.pCommandBuffers = &commandBuffer;

    VkSemaphore signalSemaphores[] = { renderFinished };
    submitInfo.signalSemaphoreCount = 1;
    submitInfo.pSignalSemaphores = signalSemaphores;

    vkQueueSubmit(graphicsQueue, 1, &submitInfo, inFlightFence);

    VkPresentInfoKHR presentInfo{};
    presentInfo.sType = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR;

    presentInfo.waitSemaphoreCount = 1;
    presentInfo.pWaitSemaphores = signalSemaphores;

    VkSwapchainKHR swapChains[] = { swapchain->get() };
    presentInfo.swapchainCount = 1;
    presentInfo.pSwapchains = swapChains;
    presentInfo.pImageIndices = &imageIndex;

    vkQueuePresentKHR(presentQueue, &presentInfo);
}


void VulkanRenderer::cleanup() {
    vertexBuffer.cleanup(device->getDevice());
}


void VulkanRenderer::createVertexBuffer() {

    vertices = {
        {{0.0f, -0.5f}, {1.0f, 0.0f, 0.0f}},
        {{0.5f, 0.5f},  {0.0f, 1.0f, 0.0f}},
        {{-0.5f, 0.5f}, {0.0f, 0.0f, 1.0f}}
    };

    VkDeviceSize bufferSize = sizeof(vertices[0]) * vertices.size();

    if (!vertexBuffer.create(
        *device,
        bufferSize,
        VK_BUFFER_USAGE_VERTEX_BUFFER_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT |
        VK_MEMORY_PROPERTY_HOST_COHERENT_BIT
    )) {
        throw std::runtime_error("Failed to create vertex buffer!");
    }

    vertexBuffer.uploadData(*device, vertices.data(), bufferSize);

    command->setVertexBuffer(vertexBuffer.get());
}



uint32_t VulkanRenderer::findMemoryType(uint32_t typeFilter, VkMemoryPropertyFlags properties) {

    VkPhysicalDeviceMemoryProperties memProperties;
    vkGetPhysicalDeviceMemoryProperties(device->getPhysicalDevice(), &memProperties);

    for (uint32_t i = 0; i < memProperties.memoryTypeCount; i++) {
        if (typeFilter & (1 << i) &&
            (memProperties.memoryTypes[i].propertyFlags & properties) == properties) {
            return i;
        }
    }

    throw std::runtime_error("Failed to find suitable memory type!");
}