#pragma once
#include <vector>
#include "VulkanMesh.h"

class VulkanDevice;

class VulkanMeshManager {
public:
    bool init(VulkanDevice& device);
    void cleanup(VkDevice device);

    VulkanMesh& createMesh(const std::vector<Vertex>& vertices);

    const std::vector<VulkanMesh>& getMeshes() const;

private:
    VulkanDevice* device = nullptr;
    std::vector<VulkanMesh> meshes;
};
