#pragma once
#include "VulkanCommand.h"
#include "VulkanSwapchain.h"
#include "VulkanPipeline.h"
#include "VulkanMesh.h"

class VulkanCommandRecorder {
public:
    void init(VulkanCommand& command);

    bool record(
        VulkanSwapchain& swapchain,
        VulkanPipeline& pipeline,
        VulkanMesh& mesh
    );

private:
    VulkanCommand* command = nullptr;
};
