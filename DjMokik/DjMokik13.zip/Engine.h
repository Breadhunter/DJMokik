#pragma once
#include "VulkanRenderer.h"
#include "Window.h"

class Engine {
public:
    bool init(Window& window);
    void run();
    void cleanup();

private:
    Window* window = nullptr;
    VulkanRenderer renderer;
};
