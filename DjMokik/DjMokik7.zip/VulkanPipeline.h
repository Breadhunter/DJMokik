#pragma once
#include <vulkan/vulkan.h>

class VulkanPipeline {
public:
    bool init(VkDevice device, VkRenderPass renderPass);
    void cleanup(VkDevice device);

    VkPipeline get() const { return pipeline; }
    VkPipelineLayout getLayout() const { return layout; }
    void createGraphicsPipeline() {};

private:
    VkPipeline pipeline = VK_NULL_HANDLE;
    VkPipelineLayout layout = VK_NULL_HANDLE;
};
