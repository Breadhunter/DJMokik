#include "VulkanSync.h"
#include <iostream>

bool VulkanSync::init(VkDevice device) {
    VkSemaphoreCreateInfo semaphoreInfo{};
    semaphoreInfo.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;

    vkCreateSemaphore(device, &semaphoreInfo, nullptr, &imageAvailable);
    vkCreateSemaphore(device, &semaphoreInfo, nullptr, &renderFinished);

    VkFenceCreateInfo fenceInfo{};
    fenceInfo.sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO;
    fenceInfo.flags = VK_FENCE_CREATE_SIGNALED_BIT;

    vkCreateFence(device, &fenceInfo, nullptr, &inFlightFence);

    return true;
}

void VulkanSync::cleanup(VkDevice device) {
    vkDestroySemaphore(device, imageAvailable, nullptr);
    vkDestroySemaphore(device, renderFinished, nullptr);
    vkDestroyFence(device, inFlightFence, nullptr);
}

