﻿#include "VulkanRenderer.h"
#include <vulkan/vulkan.h>
#include <iostream>

bool VulkanRenderer::init(
    VulkanDevice& device,
    VulkanSwapchain& swapchain,
    VulkanCommand& command,
    VulkanSync& sync,
    VulkanPipeline& pipeline
) {
    this->device = &device;
    this->swapchain = &swapchain;
    this->command = &command;
    this->sync = &sync;
    this->pipeline = &pipeline;
    return true;
}


void VulkanRenderer::drawFrame() {

    VkDevice vkDevice = device->getDevice();
    VkQueue graphicsQueue = device->getGraphicsQueue();
    VkQueue presentQueue = device->getPresentQueue();

    VkSemaphore imageAvailable = sync->getImageAvailableSemaphore();
    VkSemaphore renderFinished = sync->getRenderFinishedSemaphore();
    VkFence inFlightFence = sync->getInFlightFence();

    vkWaitForFences(vkDevice, 1, &inFlightFence, VK_TRUE, UINT64_MAX);
    vkResetFences(vkDevice, 1, &inFlightFence);

    uint32_t imageIndex;
    vkAcquireNextImageKHR(
        vkDevice,
        swapchain->get(),
        UINT64_MAX,
        imageAvailable,
        VK_NULL_HANDLE,
        &imageIndex
    );

    // 🔥 БЕРЕМ УЖЕ ГОТОВЫЙ command buffer
    VkCommandBuffer commandBuffer = command->getCommandBuffer(imageIndex);

    VkSubmitInfo submitInfo{};
    submitInfo.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;

    VkSemaphore waitSemaphores[] = { imageAvailable };
    VkPipelineStageFlags waitStages[] = { VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT };

    submitInfo.waitSemaphoreCount = 1;
    submitInfo.pWaitSemaphores = waitSemaphores;
    submitInfo.pWaitDstStageMask = waitStages;

    submitInfo.commandBufferCount = 1;
    submitInfo.pCommandBuffers = &commandBuffer;

    VkSemaphore signalSemaphores[] = { renderFinished };
    submitInfo.signalSemaphoreCount = 1;
    submitInfo.pSignalSemaphores = signalSemaphores;

    vkQueueSubmit(graphicsQueue, 1, &submitInfo, inFlightFence);

    VkPresentInfoKHR presentInfo{};
    presentInfo.sType = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR;

    presentInfo.waitSemaphoreCount = 1;
    presentInfo.pWaitSemaphores = signalSemaphores;

    VkSwapchainKHR swapChains[] = { swapchain->get() };
    presentInfo.swapchainCount = 1;
    presentInfo.pSwapchains = swapChains;
    presentInfo.pImageIndices = &imageIndex;

    vkQueuePresentKHR(presentQueue, &presentInfo);
}


void VulkanRenderer::cleanup() {}
