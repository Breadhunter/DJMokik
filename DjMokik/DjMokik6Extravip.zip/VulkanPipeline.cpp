#include "VulkanPipeline.h"
#include <iostream>

bool VulkanPipeline::init(VkDevice device, VkRenderPass renderPass) {
    std::cout << "Pipeline (stub) initialized\n";
    return true;
}

void VulkanPipeline::cleanup(VkDevice device) {
    std::cout << "Pipeline (stub) cleaned up\n";
}
