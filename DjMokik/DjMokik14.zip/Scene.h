#pragma once
#include <vector>

class VulkanMesh;

class Scene {
public:
    void addMesh(VulkanMesh& mesh);

    const std::vector<VulkanMesh*>& getMeshes() const;

private:
    std::vector<VulkanMesh*> meshes;
};
