#include "Engine.h"
#include <iostream>

bool Engine::init() {

    if (!window.init(800, 600, "DjMokik Engine")) {
        std::cerr << "Failed to create window!\n";
        return false;
    }

    if (!renderer.init(window)) {
        std::cerr << "Failed to init VulkanRenderer!\n";
        return false;
    }

    auto& meshManager = renderer.getMeshManager();

    std::vector<Vertex> vertices = {
        {{ 0.0f, -0.5f, 0.0f }, {1.0f, 0.0f, 0.0f}},
        {{ 0.5f,  0.5f, 0.0f }, {0.0f, 1.0f, 0.0f}},
        {{-0.5f,  0.5f, 0.0f }, {0.0f, 0.0f, 1.0f}}
    };

    VulkanMesh& mesh = meshManager.createMesh(vertices);

    scene.addMesh(mesh);

    renderer.renderScene(scene);

    std::cout << "Engine initialized successfully!\n";
    return true;
}

void Engine::run() {
    while (!window.shouldClose()) {
        window.pollEvents();

        renderer.drawFrame();
    }
}

void Engine::cleanup() {
    renderer.cleanup();
    window.cleanup();
}
