#include "Scene.h"
#include "VulkanMesh.h"

void Scene::addMesh(VulkanMesh& mesh) {
    meshes.push_back(&mesh);
}

const std::vector<VulkanMesh*>& Scene::getMeshes() const {
    return meshes;
}
