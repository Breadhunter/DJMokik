﻿#include "VulkanRenderer.h"
#include <iostream>

bool VulkanRenderer::init(Window& window) {

    if (!instance.init("DjMokik")) {
        std::cerr << "Failed to init Vulkan Instance!\n";
        return false;
    }

    if (!surface.init(instance.get(), window.get())) {
        std::cerr << "Failed to create Vulkan Surface!\n";
        return false;
    }

    if (!device.init(instance.get(), surface.get())) {
        std::cerr << "Failed to init Vulkan Device!\n";
        return false;
    }

    if (!swapchain.init(
        device.getPhysicalDevice(),
        device.getDevice(),
        surface.get()
    )) {
        std::cerr << "Failed to init Vulkan Swapchain!\n";
        return false;
    }

    if (!sync.init(device.getDevice())) {
        std::cerr << "Failed to init Vulkan Sync!\n";
        return false;
    }

    if (!command.init(
        device.getDevice(),
        swapchain,
        device.getGraphicsQueueFamily()
    )) {
        std::cerr << "Failed to init Vulkan Command!\n";
        return false;
    }

    if (!pipeline.init(device.getDevice(), swapchain.getRenderPass())) {
        std::cerr << "Failed to create pipeline\n";
        return false;
    }


    meshManager.init(device);
    frameManager.init(device, 2);

    return true;
}

void VulkanRenderer::drawFrame() {
    uint32_t imageIndex = frameManager.beginFrame(device, swapchain);

    VkCommandBuffer cmd = command.getCommandBuffer(imageIndex);

    frameManager.submitFrame(
        device,
        device.getGraphicsQueue(),
        cmd,
        swapchain,
        imageIndex
    );
}

void VulkanRenderer::renderScene(Scene& scene) {

    recorder.init(command);

    // Для каждого меша сцены перезаписываем команды
    for (auto mesh : scene.getMeshes()) {
        recorder.record(swapchain, pipeline, *mesh);
    }
}


void VulkanRenderer::cleanup() {

    vkDeviceWaitIdle(device.getDevice());

    meshManager.cleanup(device.getDevice());

    frameManager.cleanup(device.getDevice());

    sync.cleanup(device.getDevice());
    command.cleanup(device.getDevice());
    pipeline.cleanup(device.getDevice());
    swapchain.cleanup(device.getDevice());

    surface.cleanup(instance.get());
    device.cleanup();
    instance.cleanup();
}


