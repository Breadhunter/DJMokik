#include "VulkanMeshManager.h"
#include "VulkanDevice.h"

bool VulkanMeshManager::init(VulkanDevice& dev) {
    device = &dev;
    return true;
}

VulkanMesh& VulkanMeshManager::createMesh(const std::vector<Vertex>& vertices) {
    VulkanMesh mesh;

    mesh.create(*device, vertices);

    meshes.push_back(std::move(mesh));

    return meshes.back();
}

const std::vector<VulkanMesh>& VulkanMeshManager::getMeshes() const {
    return meshes;
}

void VulkanMeshManager::cleanup(VkDevice vkDevice) {
    for (auto& m : meshes) {
        m.cleanup(vkDevice);
    }

    meshes.clear();
}
