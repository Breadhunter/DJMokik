#pragma once

#include "Window.h"

#include "VulkanInstance.h"
#include "VulkanSurface.h"
#include "VulkanDevice.h"
#include "VulkanSwapchain.h"
#include "VulkanCommand.h"
#include "VulkanSync.h"
#include "VulkanPipeline.h"

#include "VulkanFrameManager.h"
#include "VulkanCommandRecorder.h"
#include "VulkanMeshManager.h"
#include "Scene.h"

class VulkanRenderer {
public:
    bool init(Window& window);
    void drawFrame();
    void cleanup();

    VulkanMeshManager& getMeshManager() {
        return meshManager;
    }
    void renderScene(Scene& scene);

private:
    VulkanInstance instance;
    VulkanSurface surface;
    VulkanDevice device;
    VulkanSwapchain swapchain;

    VulkanSync sync;
    VulkanCommand command;
    VulkanPipeline pipeline;

    VulkanFrameManager frameManager;
    VulkanCommandRecorder recorder;

    VulkanMeshManager meshManager;   // <---- ��� ����� �� �������
};
