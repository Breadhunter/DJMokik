#pragma once

#include "Window.h"
#include "VulkanRenderer.h"
#include "Scene.h"


class Engine {
public:
    bool init();
    void run();
    void cleanup();

private:
    Window window;
    VulkanRenderer renderer;
    Scene scene;

};
